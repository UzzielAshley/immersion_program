<?php
 include('db.php');
  $select=mysql_query("SELECT * FROM aquino order by surname asc");
  //albert;
  while($userrow=mysql_fetch_array($select))
  {
  $LRN=$userrow['lrn']; 
  $Surname=$userrow['surname'];
  $Middlename=$userrow['middlename'];
  $Age=$userrow['age'];
  $Contact=$userrow['contact'];
  $Address=$userrow['address'];
  $Birthday=$userrow['birthday'];
?>

<div class="display">
  <p> LRN : <span><?php echo $LRN; ?></span>
    <a href="delete.php?id=<?php echo $LRN; ?>" 
    onclick="return confirm('Are you sure you wish to delete this Record?');">
            <span class="delete" title="Delete"> Delete</span></a>
  </p>
  <br />
  <p> SURNAME : <span><?php echo $Surname; ?></span>
    <a href="edit.php?id=<?php echo $LRN; ?>"><span class="edit" title="Edit"> Edit </span></a>
  </p>
  <br />
  <p> MIDDLENAME : <span><?php echo $Middlename; ?></span>
  </p>
  <br />
  <p> AGE : <span><?php echo $Age; ?></span>
  </p>
  <br />
  <p> CONTACT : <span><?php echo $Contact; ?></span>
  </p>
  <br />
  <p> ADDRESS : <span><?php echo $Address; ?></span>
  </p>
  <br />
  <p> BIRTHDAY : <span><?php echo $Birthday; ?></span>
  </p>
  <br />
</div>
<?php } ?>