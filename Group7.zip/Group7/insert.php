<?php
 ob_start();
  include("db.php");
  if(isset($_POST['send'])!="")
  {
  $lrn=mysql_real_escape_string($_POST['lrn']);
  $surname=mysql_real_escape_string($_POST['surname']);
  $middlename=mysql_real_escape_string($_POST['middlename']);
  $age=mysql_real_escape_string($_POST['age']);
  $contact=mysql_real_escape_string($_POST['contact']);
  $address=mysql_real_escape_string($_POST['address']);
  $birthday=mysql_real_escape_string($_POST['birthday']);
  $update=mysql_query("INSERT INTO aquino(lrn,surname,middlename,age,contact,address,birthday)VALUES
																		('$lrn','$surname','$middlename','$age','$contact','$address','$birthday')");
  
  if($update)
  {
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:index.php');
  }
  else
  {
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
  }
  }
 ob_end_flush();
?>