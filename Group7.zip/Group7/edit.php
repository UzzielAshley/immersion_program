<?php 
ob_start();
include('db.php');
if(isset($_GET['id']))
{
  $id=$_GET['id'];
  if(isset($_POST['update']))
  {
  $lrn=$_POST['lrn'];
  $surname=$_POST['surname'];
  $middlename=$_POST['middlename'];
  $age=$_POST['age'];
  $contact=$_POST['contact'];
  $address=$_POST['address'];
  $birthday=$_POST['birthday'];
  $updated=mysql_query("UPDATE aquino SET lrn='$lrn',surname='$surname', middlename='$middlename',age='$age',contact='$contact',address='$address',birthday='$birthday'  WHERE lrn='$id' ")or die();
  if($updated)
  {
  $msg="Successfully Updated!!";
  header('Location:index.php');
  }
}
}  //ac
ob_end_flush();
?>
<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit form</title>
<link type="text/css" media="all" rel="stylesheet" href="style.css">
</head>
<body id="body2">
<?php 
  if(isset($_GET['id']))
  {
  $id=$_GET['id'];
  $getselect=mysql_query("SELECT * FROM aquino WHERE lrn='$id'");
  while($profile=mysql_fetch_array($getselect))
  {
	$lrn=$profile['lrn'];
    $surname=$profile['surname'];
    $middlename=$profile['middlename'];
    $age=$profile['age'];
	$contact=$profile['contact'];
	$address=$profile['address'];
	$birthday=$profile['birthday'];
?>
<div class="display">
  <form action="" method="post" name="insertform">
  <p>
      <label for="lrn"  id="preinput"> LRN: </label>
      <input type="text" name="lrn" required placeholder="Enter your lrn" 
      value="<?php echo $lrn; ?>" id="inputid" />
    </p>
  <p>
      <label for="surname"  id="preinput"> Surname: </label>
      <input type="text" name="surname" required placeholder="Enter your surname" 
      value="<?php echo $surname; ?>" id="inputid" />
    </p><p>
      <label  for="middlename"  id="preinput"> Middlename: </label>
      <input type="text" name="middlename" required placeholder="Enter your middlename" 
      value="<?php echo $middlename; ?>" id="inputid" />
    </p><p>
      <label for="age" id="preinput"> Age: </label>
      <input type="text" name="age" required placeholder="Enter your age" 
      value="<?php echo $age; ?>" id="inputid" />
    </p><p>
      <label for="contact" id="preinput"> Contact: </label>
      <input type="text" name="contact" required placeholder="Enter your contact" 
      value="<?php echo $contact; ?>" id="inputid" />
    </p><p>
      <label for="address" id="preinput"> Address: </label>
      <input type="text" name="address" required placeholder="Enter your address" 
      value="<?php echo $address; ?>" id="inputid" />
    </p><p>
      <label for="birthday" id="preinput"> Birthday: </label>
      <input type="text" name="birthday" required placeholder="Enter your birthday" 
      value="<?php echo $birthday; ?>" id="inputid" />
    </p>
	<p>
      <input type="submit" name="update" value="Update" id="inputid1" />
    </p>
  </form>
</div>
<?php } } ?>
</body>
</html>