<!DOCTYPE>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert form</title>
<link type="text/css" media="all" rel="stylesheet" href="style.css">
</head><body id="body1">
<div class="display">
<form action="insert.php" method="post" name="insertform">
<p>
  <label for="lrn" id="preinput"> LRN : </label>
  <input type="text" name="lrn" required placeholder="Enter your LRN" id="inputid"/>
</p>
<p>
  <label  for="surname" id="preinput"> SURNAME : </label>
  <input type="text" name="surname" required placeholder="Enter your Surname" id="inputid" />
</p>
<p>
  <label for="middlename" id="preinput"> MIDDLENAME : </label>
  <input type="text" name="middlename" required placeholder="Enter your Middlename" id="inputid" />
</p>
<p>
  <label for="age" id="preinput"> AGE : </label>
  <input type="text" name="age" required placeholder="Enter your Age" id="inputid" />
</p>
<p>
  <label for="contact" id="preinput"> CONTACT : </label>
  <input type="text" name="contact" required placeholder="Enter your Contact" id="inputid" />
</p>
<p>
  <label for="address" id="preinput"> ADDRESS : </label>
  <input type="text" name="address" required placeholder="Enter your Address" id="inputid" />
</p>
<p>
  <label for="birthday" id="preinput"> BIRTHDAY : </label>
  <input type="text" name="birthday" required placeholder="Enter your Birthday" id="inputid" />
</p>
<p>
  <input type="submit" name="send" value="Submit" id="inputid1"  />
</p>
</form></div>
<?php include('view.php'); ?>
</body></html>